use rust_decimal::Decimal;
use rust_decimal::prelude::ToPrimitive;

/// All mutable state scoped to one 5-minute prediction window.
///
/// Reset on every new `window_ts` via [`WindowState::reset`].
/// Both token sides are treated symmetrically: every field that exists
/// for UP has an exact mirror for DOWN.  No conviction ever decays or
/// is subtracted mid-window.
#[derive(Debug, Clone)]
pub struct WindowState {
    // ── BTC origin ────────────────────────────────────────────────────────
    /// VWAP computed from BTC ticks in the first 3 s of the window.
    /// Frozen once `btc_origin_locked` is true.
    pub btc_origin_price: Decimal,

    /// True once the 3-second VWAP has been frozen.
    /// `PredictionService` must suppress evaluation until this is `true`.
    pub btc_origin_locked: bool,

    /// Accumulator used only during the 0–3 s lock-in phase: (price_sum, count).
    pub(crate) btc_origin_accum: (Decimal, u32),

    /// Wall-clock ms at which the window started (= window_ts * 1000).
    pub window_started_ms: u64,

    /// Last observed BTC price — needed to compute per-tick pct-change.
    pub btc_last_price: Decimal,

    /// Last BTC update timestamp in ms.
    pub btc_last_update_ms: u64,

    /// Signed (current − origin) / origin for BTC, updated each tick.
    pub btc_distance_from_origin_pct: f64,

    /// Time-weighted area under the BTC distance-from-origin curve.
    /// Accumulated as `distance_pct * dt_seconds` on every tick.
    pub btc_area: f64,

    /// Cumulative positive-tick points: `pct_change * 1000` for each tick
    /// where BTC rose.  Only grows; never subtracted.
    pub btc_bull_points: f64,

    /// Cumulative magnitude of negative ticks, stored separately.
    /// Never subtracted from bull points — preserves full information.
    pub btc_bear_points: f64,

    // ── UP token conviction ───────────────────────────────────────────────
    /// Price at the first trade of the UP token this window.
    pub up_origin_price: Decimal,

    /// Last observed UP trade price.
    pub up_last_price: Decimal,

    /// Last UP update timestamp in ms.
    pub up_last_update_ms: u64,

    /// Signed (current − origin) / origin for the UP token.
    pub up_distance_from_origin_pct: f64,

    /// Time-weighted AUC: Σ(distance_from_origin_pct * dt_seconds).
    pub up_area: f64,

    /// Cumulative positive-tick points for UP.  Only grows.
    pub up_positive_points: f64,

    /// Cumulative magnitude of negative ticks for UP.  Tracked separately.
    pub up_negative_points: f64,

    // ── DOWN token conviction ─────────────────────────────────────────────
    /// Price at the first trade of the DOWN token this window.
    pub down_origin_price: Decimal,

    /// Last observed DOWN trade price.
    pub down_last_price: Decimal,

    /// Last DOWN update timestamp in ms.
    pub down_last_update_ms: u64,

    /// Signed (current − origin) / origin for the DOWN token.
    pub down_distance_from_origin_pct: f64,

    /// Time-weighted AUC: Σ(distance_from_origin_pct * dt_seconds).
    pub down_area: f64,

    /// Cumulative positive-tick points for DOWN.  Only grows.
    pub down_positive_points: f64,

    /// Cumulative magnitude of negative ticks for DOWN.  Tracked separately.
    pub down_negative_points: f64,
}

impl Default for WindowState {
    fn default() -> Self {
        Self {
            btc_origin_price: Decimal::ZERO,
            btc_origin_locked: false,
            btc_origin_accum: (Decimal::ZERO, 0),
            window_started_ms: 0,
            btc_last_price: Decimal::ZERO,
            btc_last_update_ms: 0,
            btc_distance_from_origin_pct: 0.0,
            btc_area: 0.0,
            btc_bull_points: 0.0,
            btc_bear_points: 0.0,

            up_origin_price: Decimal::ZERO,
            up_last_price: Decimal::ZERO,
            up_last_update_ms: 0,
            up_distance_from_origin_pct: 0.0,
            up_area: 0.0,
            up_positive_points: 0.0,
            up_negative_points: 0.0,

            down_origin_price: Decimal::ZERO,
            down_last_price: Decimal::ZERO,
            down_last_update_ms: 0,
            down_distance_from_origin_pct: 0.0,
            down_area: 0.0,
            down_positive_points: 0.0,
            down_negative_points: 0.0,
        }
    }
}

impl WindowState {
    /// Reset to a clean slate for a new window.
    /// `window_started_ms` must be the window's start time in milliseconds.
    pub fn reset(&mut self, window_started_ms: u64) {
        *self = Self::default();
        self.window_started_ms = window_started_ms;
    }

    // ── BTC ───────────────────────────────────────────────────────────────

    /// Ingest one BTC price tick.
    ///
    /// During the first 3 seconds the price is accumulated for the VWAP.
    /// Once the VWAP is frozen all distance, AUC, and point metrics update.
    pub fn ingest_btc(&mut self, price: Decimal, timestamp_ms: u64) {
        // ── Lock-in phase (0 – 3 s) ───────────────────────────────────────
        if !self.btc_origin_locked {
            let elapsed_ms =
                timestamp_ms.saturating_sub(self.window_started_ms);

            if elapsed_ms <= 3_000 {
                self.btc_origin_accum.0 += price;
                self.btc_origin_accum.1 += 1;
                self.btc_last_price = price;
                self.btc_last_update_ms = timestamp_ms;
                return;
            }

            // 3 s have passed — freeze the VWAP.
            self.btc_origin_price = if self.btc_origin_accum.1 > 0 {
                self.btc_origin_accum.0
                    / Decimal::from(self.btc_origin_accum.1)
            } else {
                // Fallback: no ticks arrived during lock-in, use current.
                price
            };

            self.btc_origin_locked = true;
        }

        // ── Running update ────────────────────────────────────────────────
        let origin_f = match self.btc_origin_price.to_f64() {
            Some(v) if v > 0.0 => v,
            _ => return,
        };

        let current_f = match price.to_f64() {
            Some(v) => v,
            None => return,
        };

        // Distance from origin.
        let distance_pct = (current_f - origin_f) / origin_f;
        self.btc_distance_from_origin_pct = distance_pct;

        // Time-weighted AUC.
        let dt = timestamp_ms
            .saturating_sub(self.btc_last_update_ms) as f64
            / 1_000.0;
        self.btc_area += distance_pct * dt;

        // Per-tick pct-change for conviction points.
        if !self.btc_last_price.is_zero() {
            if let Some(prev_f) = self.btc_last_price.to_f64() {
                if prev_f > 0.0 {
                    let pct_change = (current_f - prev_f) / prev_f;
                    if pct_change > 0.0 {
                        self.btc_bull_points += pct_change * 1_000.0;
                    } else if pct_change < 0.0 {
                        self.btc_bear_points += pct_change.abs() * 1_000.0;
                    }
                }
            }
        }

        self.btc_last_price = price;
        self.btc_last_update_ms = timestamp_ms;
    }

    // ── Token helpers (symmetric) ─────────────────────────────────────────

    /// Ingest a new UP token trade price.
    pub fn ingest_up(&mut self, price: Decimal, timestamp_ms: u64) {
        Self::ingest_token(
            price,
            timestamp_ms,
            &mut self.up_origin_price,
            &mut self.up_last_price,
            &mut self.up_last_update_ms,
            &mut self.up_distance_from_origin_pct,
            &mut self.up_area,
            &mut self.up_positive_points,
            &mut self.up_negative_points,
        );
    }

    /// Ingest a new DOWN token trade price.
    pub fn ingest_down(&mut self, price: Decimal, timestamp_ms: u64) {
        Self::ingest_token(
            price,
            timestamp_ms,
            &mut self.down_origin_price,
            &mut self.down_last_price,
            &mut self.down_last_update_ms,
            &mut self.down_distance_from_origin_pct,
            &mut self.down_area,
            &mut self.down_positive_points,
            &mut self.down_negative_points,
        );
    }

    /// Shared logic for both token sides — guarantees exact symmetry.
    #[allow(clippy::too_many_arguments)]
    fn ingest_token(
        price: Decimal,
        timestamp_ms: u64,
        origin_price: &mut Decimal,
        last_price: &mut Decimal,
        last_update_ms: &mut u64,
        distance_from_origin_pct: &mut f64,
        area: &mut f64,
        positive_points: &mut f64,
        negative_points: &mut f64,
    ) {
        // Set origin on the very first trade of the window.
        if origin_price.is_zero() {
            *origin_price = price;
            *last_price = price;
            *last_update_ms = timestamp_ms;
            return;
        }

        let origin_f = match origin_price.to_f64() {
            Some(v) if v > 0.0 => v,
            _ => return,
        };

        let current_f = match price.to_f64() {
            Some(v) => v,
            None => return,
        };

        // Signed distance from this token's window origin.
        let dist = (current_f - origin_f) / origin_f;
        *distance_from_origin_pct = dist;

        // Time-weighted AUC.
        let dt = timestamp_ms.saturating_sub(*last_update_ms) as f64
            / 1_000.0;
        *area += dist * dt;

        // Per-tick conviction points — percentage change from previous price.
        if let Some(prev_f) = last_price.to_f64() {
            if prev_f > 0.0 {
                let pct_change = (current_f - prev_f) / prev_f;
                if pct_change > 0.0 {
                    *positive_points += pct_change * 1_000.0;
                } else if pct_change < 0.0 {
                    *negative_points += pct_change.abs() * 1_000.0;
                }
            }
        }

        *last_price = price;
        *last_update_ms = timestamp_ms;
    }
}