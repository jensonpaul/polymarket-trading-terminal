use std::collections::HashMap;
use std::collections::VecDeque;
use std::sync::Arc;
use std::time::Duration;

use futures::StreamExt;
use rust_decimal::Decimal;
use tokio::sync::RwLock;
use tracing::info;
use tracing::warn;

use polymarket_client_sdk_v2::{
    clob::ws::Client,
    types::U256,
};

use crate::prediction::{
    OrderbookSample,
    RollingWindow,
    TokenFeatures,
    WindowState,
};

#[derive(Debug, Clone)]
pub struct MarketAssets {
    pub up_asset_id: U256,
    pub down_asset_id: U256,
}

struct TokenWindow {
    window_ts: u64,
    expires_at_sec: u64,
    window: RollingWindow<OrderbookSample>,
}

#[derive(Debug, Clone)]
struct OrderbookState {
    best_bid: Decimal,
    best_ask: Decimal,
    bid_depth: Decimal,
    ask_depth: Decimal,
    timestamp_ms: u64,
}

pub struct PolymarketFeed {
    client: Client,

    windows: Arc<RwLock<HashMap<String, TokenWindow>>>,

    latest_orderbooks: Arc<RwLock<HashMap<String, OrderbookState>>>,

    /// Shared with BtcFeed and PredictionService.
    window_state: Arc<RwLock<WindowState>>,
}

impl PolymarketFeed {
    pub fn new(window_state: Arc<RwLock<WindowState>>) -> Self {
        Self {
            client: Client::default(),
            windows: Arc::new(RwLock::new(HashMap::new())),
            latest_orderbooks: Arc::new(RwLock::new(HashMap::new())),
            window_state,
        }
    }

    pub async fn run_market(
        &self,
        assets: MarketAssets,
        window_ts: u64,
    ) -> anyhow::Result<()> {
        let expires_at_sec = window_ts + 300;

        let up_id = assets.up_asset_id.to_string();
        let down_id = assets.down_asset_id.to_string();

        let asset_ids = vec![
            assets.up_asset_id,
            assets.down_asset_id,
        ];

        let orderbook_stream = self
            .client
            .subscribe_orderbook(asset_ids.clone())?;

        let mut orderbook_stream = Box::pin(orderbook_stream);

        info!(
            %window_ts,
            %expires_at_sec,
            "market websocket started"
        );

        loop {
            let now_sec = chrono::Utc::now().timestamp() as u64;

            if now_sec >= expires_at_sec {
                info!(%window_ts, "market expired");
                self.evict_market(&assets).await;
                break;
            }

            
            let msg = orderbook_stream.next().await;
            let Some(msg) = msg else { break; };
            let book = msg?;

            /*
            let best_bid = book
                .bids
                .first()
                .map(|v| v.price)
                .unwrap_or_default();

            let best_ask = book
                .asks
                .first()
                .map(|v| v.price)
                .unwrap_or_default();
            */

            let best_bid = book
                .bids
                .iter()
                .max_by_key(|v| v.price)
                .map(|v| v.price)
                .unwrap_or(Decimal::ZERO);

            let best_ask = book
                .asks
                .iter()
                .min_by_key(|v| v.price)
                .map(|v| v.price)
                .unwrap_or(Decimal::ZERO);

            let bid_depth: Decimal =
                book.bids.iter().map(|v| v.size).sum();

            let ask_depth: Decimal =
                book.asks.iter().map(|v| v.size).sum();

            let timestamp_ms =
                chrono::Utc::now().timestamp_millis() as u64;

            self.latest_orderbooks
                .write()
                .await
                .insert(
                    book.asset_id.to_string(),
                    OrderbookState {
                        best_bid,
                        best_ask,
                        bid_depth,
                        ask_depth,
                        timestamp_ms,
                    },
                );

            self.try_publish_sample(
                book.asset_id.to_string(),
                expires_at_sec,
                &up_id,
                &down_id,
            )
            .await;
        }

        info!(%window_ts, "market websocket closed");

        Ok(())
    }

    async fn try_publish_sample(
        &self,
        asset_id: String,
        expires_at_sec: u64,
        up_id: &str,
        down_id: &str,
    ) {
        let orderbook = {
            self.latest_orderbooks
                .read()
                .await
                .get(&asset_id)
                .cloned()
        };

        let Some(orderbook) = orderbook else {
             return;
        };
 
        // Do not ingest or publish when the orderbook has no asks.
        if orderbook.best_ask.is_zero() {
            return;
        }

        // The orderbook stream carries the full asks vec in each message,
        // so we re-read it from the raw book here via a dedicated field.
        let current_price = orderbook.best_ask;

         let sample = OrderbookSample {
            timestamp_ms: orderbook.timestamp_ms,
             asset_id: asset_id.clone(),
             best_bid: orderbook.best_bid,
             best_ask: orderbook.best_ask,
             bid_depth: orderbook.bid_depth,
             ask_depth: orderbook.ask_depth,
         };
 
         // Update window-scoped conviction state.
         {
             let mut ws = self.window_state.write().await;
             if asset_id == up_id {
                ws.ingest_up(current_price, orderbook.timestamp_ms);
             } else if asset_id == down_id {
                ws.ingest_down(current_price, orderbook.timestamp_ms);
             }
         }
 
         self.push(sample, expires_at_sec).await;
    }

    async fn push(&self, sample: OrderbookSample, expires_at_sec: u64) {
        let now_sec = chrono::Utc::now().timestamp() as u64;
        let mut windows = self.windows.write().await;

        let token_window = windows
            .entry(sample.asset_id.clone())
            .or_insert_with(|| TokenWindow {
                window_ts: expires_at_sec.saturating_sub(300),
                expires_at_sec,
                window: RollingWindow::new(Duration::from_secs(300)),
            });

        token_window.window.push(sample);
    }

    /// Returns token features for a given asset, combining rolling-window
    /// orderbook data with window-wide conviction state.
    ///
    /// `is_up` must be `true` for `token_ids[0]` and `false` for `token_ids[1]`.
    pub async fn token_features(
        &self,
        asset_id: &str,
        is_up: bool,
    ) -> Option<TokenFeatures> {
        let windows = self.windows.read().await;
        let token_window = windows.get(asset_id)?;
        let latest = token_window.window.latest()?;

        // Use best_ask as the current price
        let current_price = latest.best_ask;

        let spread = latest.best_ask - latest.best_bid;

        let spread_pct = if current_price.is_zero() {
            0.0
        } else {
            (spread / current_price)
                .to_string()
                .parse()
                .unwrap_or(0.0)
        };

        let bid_depth_f = latest
            .bid_depth
            .to_string()
            .parse::<f64>()
            .unwrap_or(0.0);

        let ask_depth_f = latest
            .ask_depth
            .to_string()
            .parse::<f64>()
            .unwrap_or(0.0);

        let imbalance = if (bid_depth_f + ask_depth_f) <= 0.0 {
            0.0
        } else {
            (bid_depth_f - ask_depth_f) / (bid_depth_f + ask_depth_f)
        };

        // Pull conviction fields from window state.
        let ws = self.window_state.read().await;

        let (
            origin_price,
            distance_from_origin_pct,
            positive_points,
            negative_points,
            area_under_curve,
        ) = if is_up {
            (
                ws.up_origin_price,
                ws.up_distance_from_origin_pct,
                ws.up_positive_points,
                ws.up_negative_points,
                ws.up_area,
            )
        } else {
            (
                ws.down_origin_price,
                ws.down_distance_from_origin_pct,
                ws.down_positive_points,
                ws.down_negative_points,
                ws.down_area,
            )
        };

        Some(TokenFeatures {
            current_price,
            origin_price,
            distance_from_origin_pct,
            positive_points,
            negative_points,
            area_under_curve,
            bid_depth: latest.bid_depth,
            ask_depth: latest.ask_depth,
            imbalance,
            spread_pct,
        })
    }

    async fn evict_market(&self, assets: &MarketAssets) {
         let up = assets.up_asset_id.to_string();
         let down = assets.down_asset_id.to_string();
 
        // Drain both token windows before removing them so the samples
        // can be written to disk without blocking the async runtime.
        let mut to_dump: Vec<(String, u64, VecDeque<OrderbookSample>)> =
            Vec::new();

        {
            let mut windows = self.windows.write().await;
            if let Some(tw) = windows.remove(&up) {
                to_dump.push(("up".to_string(), tw.window_ts, tw.window.samples().clone()));
            }
            if let Some(tw) = windows.remove(&down) {
                to_dump.push(("down".to_string(), tw.window_ts, tw.window.samples().clone()));
            }
        }

        // Spawn a blocking task so JSON serialisation  disk I/O never
        // stall the Tokio executor.
        if !to_dump.is_empty() {
            tokio::task::spawn_blocking(move || {
                for (side, window_ts, samples) in to_dump {
                    Self::write_window_dump(&side, window_ts, &samples);
                }
            });
        }

         self.latest_orderbooks.write().await.remove(&up);
         self.latest_orderbooks.write().await.remove(&down);
    }

    /// Serialise all `OrderbookSample`s from one token's 5-minute window to
    /// a newline-delimited JSON file.
    ///
    /// Path format: `orderbook_dumps/<window_ts>_<side>.ndjson`
    ///
    /// Called from a `spawn_blocking` context — blocking I/O is intentional.
    fn write_window_dump(
        side: &str,
        window_ts: u64,
        samples: &VecDeque<OrderbookSample>,
    ) {
        use std::fs;
        use std::io::Write;

        if samples.is_empty() {
            return;
        }

        let dir = std::path::Path::new("orderbook_dumps");
        if let Err(e) = fs::create_dir_all(dir) {
            warn!(%side, error=%e, "failed to create orderbook_dumps dir");
            return;
        }

        let path = dir.join(format!("{}_{}.ndjson", window_ts, side));

        let file = match fs::File::create(&path) {
            Ok(f) => f,
            Err(e) => {
                warn!(
                    %side,
                    path=%path.display(),
                    error=%e,
                    "failed to create dump file"
                );
                return;
            }
        };

        let mut writer = std::io::BufWriter::new(file);

        for sample in samples {
            match serde_json::to_string(sample) {
                Ok(line) => {
                    if let Err(e) = writeln!(writer, "{}", line) {
                        warn!(%side, error=%e, "write error mid-dump");
                        return;
                    }
                }
                Err(e) => {
                    warn!(%side, error=%e, "serialise error mid-dump");
                }
            }
        }

        info!(
            %side,
            %window_ts,
            samples = samples.len(),
            path = %path.display(),
            "orderbook window dumped"
        );
    }
}