//! # Hype Reversion Strategy
//!
//! Mean-reversion play on Polymarket BTC UP/DOWN 5-minute markets.
//!
//! ## Core Thesis
//!
//! Polymarket token prices are distorted by crowd sentiment reacting to BTC's
//! current position relative to its recent range:
//!
//! - BTC near its 5-minute **high** → traders hype the **DOWN** token
//!   (expecting BTC to fall), inflating its price above fair value.
//! - BTC near its 5-minute **low** → traders hype the **UP** token
//!   (expecting BTC to rise), inflating its price above fair value.
//!
//! The inflated (hyped) token will settle back toward fair value as the window
//! progresses.  The **opposite** (trending/settling) token is simultaneously
//! suppressed — it is the buy target.
//!
//! ## Entry Logic
//!
//! Buy the **trending side** (opposite of hyped) when:
//!   1. The trending token has fallen into the ideal buy band (0.05–0.12 USDC).
//!   2. BTC is at a relative extreme in its 5-minute range.
//!   3. BTC volatility is elevated (creates snap-back breathing room).
//!   4. Overall confidence score meets the minimum threshold.
//!
//! ## Exit / Pricing Logic
//!
//! Exit targets depend on the **decay type** of the trending token's drop:
//!
//! | DecayType | Drop Pattern              | Expected Bounce | Multiplier |
//! |-----------|--------------------------|-----------------|------------|
//! | Sudden    | Sharp cliff drop          | ~50–100%        | ×1.80      |
//! | Gradual   | Steady slope down         | ~20–40%         | ×1.40      |
//! | Flat      | Barely moved / at floor   | ~10%            | ×1.15      |
//!
//! Additionally, **absolute price** overrides the multiplier at extremes:
//!   - Price ≤ 0.07: snap-back target is 0.12–0.15 (floor bounce).
//!   - Price 0.07–0.12: target is 0.18–0.25 depending on decay type.
//!   - Price 0.12–0.20: target is 0.25–0.35.
//!
//! ## Late-Window Safety
//!
//! Entries are blocked with ≤30 seconds remaining — settlement risk.
//!
//! ## High-Volatility Hyped-Side Edge Case
//!
//! When BTC volatility is very high and the winning (hyped) side has not
//! moved far from its window origin, even the hyped side can spike briefly.
//! This case is flagged in the signal reason but requires a mandatory exit
//! before 30 seconds; the strategy issues a normal Buy signal on the hyped
//! side only under these specific conditions.

use rust_decimal::Decimal;
use rust_decimal::prelude::FromPrimitive;
use rust_decimal_macros::dec;

use crate::prediction::{
    DecayType,
    HypeAnalysis,
    MarketAnalyzer,
    PredictionContext,
    PredictionSide,
    PredictionSignal,
    PredictionStrategy,
    SignalType,
};

// ── Tuning constants ──────────────────────────────────────────────────────────

/// Minimum confidence to emit a Buy signal.
const MIN_CONFIDENCE: f64 = 52.0;

/// Ideal buy band upper bound.  Entries above this price have worse
/// risk/reward for the mean-reversion play.
const IDEAL_BUY_MAX: f64 = 0.20;

/// Hard floor — below this price the token is likely to expire worthless;
/// snap-back is still possible but risk of zero is real.
const FLOOR_PRICE: f64 = 0.03;

/// Maximum BTC volatility (30s) above which the hyped-side edge case is
/// potentially active (very high volatility = crowd over-reaction).
const HIGH_VOL_THRESHOLD: f64 = 0.0015;

/// When hyped-side price has moved less than this fraction from its window
/// origin, the high-volatility edge case may apply.
const HYPED_ORIGIN_PROXIMITY: f64 = 0.08;

// ─────────────────────────────────────────────────────────────────────────────

#[derive(Debug, Default)]
pub struct HypeReversionStrategy {
    pub min_confidence: f64,
}

impl HypeReversionStrategy {
    pub fn new() -> Self {
        Self {
            min_confidence: MIN_CONFIDENCE,
        }
    }

    // ── Exit price calculation ────────────────────────────────────────────

    /// Compute target exit and stop-loss for the trending side based on the
    /// absolute entry price and the token's decay pattern.
    ///
    /// The strategy notes are explicit: for a token at 0.05 the dynamics are
    /// completely different from one at 0.50.  Relative multipliers alone are
    /// inadequate — we blend them with absolute price anchors.
    fn compute_exits(
        entry: f64,
        decay: DecayType,
    ) -> (Decimal, Decimal) {
        // ── Absolute-price anchors (primary) ─────────────────────────────
        //
        // These reflect the strategy notes' ideal prices:
        //   "buy around 0.05–0.12, sell at 0.10–0.20"
        let (abs_exit, abs_stop) = if entry <= 0.07 {
            // Floor zone: snap-back from near-zero.
            // Even a Flat token at 0.05 can reach 0.10.
            match decay {
                DecayType::Sudden  => (0.16, 0.03),
                DecayType::Gradual => (0.12, 0.03),
                DecayType::Flat    => (0.10, 0.03),
            }
        } else if entry <= 0.12 {
            // Ideal buy band.
            match decay {
                DecayType::Sudden  => (0.25, 0.06),
                DecayType::Gradual => (0.20, 0.06),
                DecayType::Flat    => (0.15, 0.06),
            }
        } else if entry <= 0.20 {
            // Acceptable band — still a meaningful suppression discount.
            match decay {
                DecayType::Sudden  => (0.35, 0.10),
                DecayType::Gradual => (0.28, 0.10),
                DecayType::Flat    => (0.22, 0.10),
            }
        } else {
            // Above 0.20 — less ideal; fall back to relative multiplier.
            let multiplier = match decay {
                DecayType::Sudden  => 1.80,
                DecayType::Gradual => 1.40,
                DecayType::Flat    => 1.20,
            };
            (entry * multiplier, entry * 0.65)
        };

        // ── Relative multiplier (secondary / sanity check) ────────────────
        //
        // Ensure the absolute exit is at least as good as the relative
        // multiplier would give — we take the maximum.
        let rel_multiplier = match decay {
            DecayType::Sudden  => 1.80,
            DecayType::Gradual => 1.40,
            DecayType::Flat    => 1.15,
        };
        let rel_exit = entry * rel_multiplier;

        let final_exit = abs_exit.max(rel_exit);
        let final_stop = abs_stop.min(entry * 0.60); // never worse than -40%

        let exit_dec = Decimal::from_f64(final_exit)
            .unwrap_or(dec!(0.20));
        let stop_dec = Decimal::from_f64(final_stop)
            .unwrap_or(dec!(0.05));

        (exit_dec, stop_dec)
    }

    // ── Hyped-side edge case check ────────────────────────────────────────

    /// Returns true if the high-volatility hyped-side trade is applicable.
    ///
    /// Conditions (all must hold):
    ///   - BTC volatility is very high (crowd likely over-reacted)
    ///   - Hyped-side token has NOT moved far from its window origin
    ///   - Caller already passed the ≤30s gate
    fn hyped_side_edge_case(
        ctx: &PredictionContext,
        analysis: &HypeAnalysis,
    ) -> bool {
        let btc_vol = ctx.btc.volatility_30s;

        if btc_vol < HIGH_VOL_THRESHOLD {
            return false;
        }

        // How far has the hyped token drifted from its window start?
        let hyped_feat = match analysis.hyped_side {
            PredictionSide::Up   => &ctx.polymarket.up,
            PredictionSide::Down => &ctx.polymarket.down,
        };
        let hyped_drift = hyped_feat.distance_from_origin_pct.abs();

        hyped_drift < HYPED_ORIGIN_PROXIMITY
    }
}

impl PredictionStrategy for HypeReversionStrategy {
    fn name(&self) -> &'static str {
        "hype_reversion"
    }

    fn evaluate(
        &self,
        ctx: &PredictionContext,
    ) -> Option<PredictionSignal> {
        // ── Late-window gate ─────────────────────────────────────────────
        if ctx.seconds_remaining <= 30 {
            return Some(PredictionSignal::no_trade(
                "settlement window",
                ctx.timestamp_ms,
            ));
        }

        // ── Compute hype/trending analysis ───────────────────────────────
        let analysis = MarketAnalyzer::hype_analysis(ctx)?;

        // ── Check high-volatility hyped-side edge case ───────────────────
        //
        // "When there is high volatility and the price difference is not far
        // from the starting price, even the hyped side is profitable."
        // Gate: must exit before last 30 s (already guarded above).
        let edge_case = Self::hyped_side_edge_case(ctx, &analysis);

        // ── Confidence gate ───────────────────────────────────────────────
        if analysis.confidence < self.min_confidence && !edge_case {
            return None;
        }

        // ── Determine final trade side ────────────────────────────────────
        //
        // Normal path: buy the trending side (opposite of hyped).
        // Edge case: buy the hyped side briefly under very high BTC volatility.
        let (target_side, trade_price, is_edge_case) = if edge_case
            && analysis.hyped_price_f64 > FLOOR_PRICE
            && analysis.hyped_price_f64 <= IDEAL_BUY_MAX
        {
            (analysis.hyped_side, analysis.hyped_price_f64, true)
        } else {
            (analysis.trending_side, analysis.trending_price_f64, false)
        };

        // ── Price validity checks ─────────────────────────────────────────
        if trade_price <= FLOOR_PRICE {
            return None; // too close to zero — stop/loss risk of full wipeout
        }

        // For the normal path, prefer the ideal buy band.
        // Allow entries up to IDEAL_BUY_MAX; above that the r/r deteriorates.
        if !is_edge_case && trade_price > IDEAL_BUY_MAX {
            return None;
        }

        // ── Convert entry price ───────────────────────────────────────────
        let entry = match Decimal::from_f64(trade_price) {
            Some(v) if v > Decimal::ZERO => v,
            _ => return None,
        };

        // ── Compute exits ─────────────────────────────────────────────────
        //
        // Edge-case hyped-side trades use Flat multiplier with tight targets
        // (mandatory short hold — exit before 30 s).
        let decay = if is_edge_case {
            DecayType::Gradual
        } else {
            analysis.decay_type
        };
        let (target_exit, stop_loss) =
            Self::compute_exits(trade_price, decay);

        // ── BTC volatility context ────────────────────────────────────────
        let btc_vol = ctx
            .btc
            .volatility_30s
            .max(ctx.btc.volatility_60s);

        // ── Build signal ──────────────────────────────────────────────────
        let edge_tag = if is_edge_case { " [EDGE:hyped]" } else { "" };
        let reason = format!(
            "hyped={:?} trending={:?} decay={:?} \
             btcRange={:.2} btcVol={:.4} \
             entry={:.4} exit={:.4} stop={:.4}{}",
            analysis.hyped_side,
            analysis.trending_side,
            analysis.decay_type,
            ctx.btc.range_position,
            btc_vol,
            trade_price,
            target_exit,
            stop_loss,
            edge_tag,
        );

        Some(PredictionSignal {
            signal_type: SignalType::Buy,
            side: target_side,
            confidence: analysis.confidence,
            target_entry: entry,
            target_exit,
            stop_loss,
            generated_at_ms: ctx.timestamp_ms,
            reason,
        })
    }
}
