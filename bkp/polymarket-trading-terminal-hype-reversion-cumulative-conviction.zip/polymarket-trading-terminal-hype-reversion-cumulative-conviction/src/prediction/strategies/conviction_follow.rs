use rust_decimal_macros::dec;

use crate::prediction::{
    MarketAnalyzer,
    PredictionContext,
    PredictionSide,
    PredictionSignal,
    PredictionStrategy,
    SignalType,
};

/// Trend-following strategy driven by the window-wide conviction engine.
///
/// Trades *with* the dominant side — the side that has accumulated more
/// cumulative positive-tick points and a larger time-weighted AUC over the
/// 5-minute window.  This replaces the old mean-reversion approach whose
/// short-term velocity/acceleration signals were inadequate for capturing
/// sustained market conviction.
#[derive(Debug, Default)]
pub struct ConvictionFollowStrategy {
    pub min_confidence: f64,
}

impl ConvictionFollowStrategy {
    pub fn new() -> Self {
        Self {
            min_confidence: 55.0,
        }
    }
}

impl PredictionStrategy for ConvictionFollowStrategy {
    fn name(&self) -> &'static str {
        "conviction_follow"
    }

    fn evaluate(
        &self,
        ctx: &PredictionContext,
    ) -> Option<PredictionSignal> {
        // Gate: BTC origin must be locked before any signal is valid.
        if ctx.btc.origin_price.is_zero() {
            return None;
        }

        // Avoid late-window entries — settlement risk outweighs upside.
        if ctx.seconds_remaining <= 30 {
            return Some(PredictionSignal::no_trade(
                "settlement window",
                ctx.timestamp_ms,
            ));
        }

        let elapsed =
            300u64.saturating_sub(ctx.seconds_remaining) as f64;

        let analysis =
            MarketAnalyzer::conviction_analysis(ctx, elapsed)?;

        if analysis.confidence < self.min_confidence {
            return None;
        }

        // Trend-following: trade WITH the dominant side.
        let target_side = analysis.dominant_side;

        let target_token = match target_side {
            PredictionSide::Up => &ctx.polymarket.up,
            PredictionSide::Down => &ctx.polymarket.down,
        };

        let entry = target_token.current_price;
        if entry.is_zero() {
            return None;
        }

        let target_exit = entry * dec!(1.40);
        let stop_loss   = entry * dec!(0.70);

        Some(PredictionSignal {
            signal_type: SignalType::Buy,
            side: target_side,
            confidence: analysis.confidence,
            target_entry: entry,
            target_exit,
            stop_loss,
            generated_at_ms: ctx.timestamp_ms,
            reason: format!(
                "dominant={:?} gap={:.2} btc_align={:.0} \
                 rate_up={:.3} rate_dn={:.3} btc_dist={:.4}",
                analysis.dominant_side,
                analysis.conviction_gap,
                analysis.btc_alignment,
                analysis.up_conviction_rate,
                analysis.down_conviction_rate,
                ctx.btc.distance_from_origin_pct,
            ),
        })
    }
}