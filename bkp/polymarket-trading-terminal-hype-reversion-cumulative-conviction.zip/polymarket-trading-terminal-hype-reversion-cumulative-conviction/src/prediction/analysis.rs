use rust_decimal::prelude::ToPrimitive;

use crate::prediction::{
    DecayType,
    PredictionContext,
    PredictionSide,
};

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// ConvictionAnalysis — measures *which side has been inflating*.
//
// Used by the mean-reversion strategy to reliably identify the hyped side.
// The conviction score measures cumulative price inflation across the window;
// the *dominant* side here is the HYPED side (the one to fade, not follow).
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

#[derive(Debug, Clone)]
pub struct ConvictionAnalysis {
    /// The token side whose cumulative conviction score is higher.
    /// This is the **hyped** side — the one being artificially bid up by
    /// BTC-position sentiment.  The mean-reversion strategy buys the opposite.
    pub dominant_side: PredictionSide,

    /// Raw difference between the two conviction scores.
    pub conviction_gap: f64,

    /// +1.0 when BTC's direction from its origin aligns with `dominant_side`;
    /// −1.0 when it opposes.
    pub btc_alignment: f64,

    /// Final blended confidence, clamped to [0, 100].
    pub confidence: f64,

    /// conviction / elapsed_seconds for the UP side.
    pub up_conviction_rate: f64,

    /// conviction / elapsed_seconds for the DOWN side.
    pub down_conviction_rate: f64,
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// HypeAnalysis — the complete picture needed by HypeReversionStrategy.
//
// Identifies hyped vs. trending sides, characterises the drop pattern of the
// settling (trending) token, and scores confidence for a mean-reversion entry.
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

#[derive(Debug, Clone)]
pub struct HypeAnalysis {
    /// Side that is artificially inflated by BTC-position sentiment.
    /// This is the side to avoid (or exit quickly).
    pub hyped_side: PredictionSide,

    /// Side that is being suppressed / settling downward.
    /// This is the side to BUY for mean-reversion.
    pub trending_side: PredictionSide,

    /// How the trending token's price has been dropping.
    /// Determines expected snap-back magnitude and profit multiplier.
    pub decay_type: DecayType,

    /// Confidence score [0, 100] for this mean-reversion setup.
    ///
    /// High when:
    ///   - BTC is at a relative extreme (high or low in its 5m range)
    ///   - BTC volatility is elevated
    ///   - The trending-side token has dropped significantly from its origin
    ///   - The token's current price is in the ideal buy band (0.05–0.12)
    pub confidence: f64,

    /// Absolute price of the trending (buy-target) token right now.
    pub trending_price_f64: f64,

    /// Absolute price of the hyped token right now.
    pub hyped_price_f64: f64,
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// MarketAnalyzer
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

pub struct MarketAnalyzer;

impl MarketAnalyzer {
    // ─────────────────────────────────────────────────────────────────────
    // hype_analysis — the primary entry point for HypeReversionStrategy.
    //
    // Algorithm:
    //
    //  1. Determine which token is hyped from two orthogonal signals:
    //       a) BTC macro position (range_position): BTC near 5m high →
    //          DOWN token is hyped (crowd expects BTC to fall);
    //          BTC near 5m low → UP token is hyped.
    //       b) Window-wide conviction: the side with higher cumulative
    //          positive points + AUC has been inflating → hyped.
    //     When both signals agree the confidence bonus is large.
    //
    //  2. Trending side = opposite of hyped.
    //
    //  3. Classify the trending token's drop pattern (DecayType) from:
    //       - Speed: how far it has fallen relative to elapsed time
    //       - Shape: ratio of negative_points to the total price move
    //         (high ratio = lots of tick-by-tick selling = gradual;
    //          low ratio with large distance = sudden dump)
    //
    //  4. Score confidence using:
    //       - BTC at extreme (range_position ≥ 0.80 or ≤ 0.20)
    //       - BTC volatility (30s + 60s combined)
    //       - Trending token's distance from its window origin (how far it fell)
    //       - Absolute price proximity to the ideal buy band (0.05–0.12)
    //       - Signal agreement bonus
    // ─────────────────────────────────────────────────────────────────────
    pub fn hype_analysis(ctx: &PredictionContext) -> Option<HypeAnalysis> {
        let up = &ctx.polymarket.up;
        let down = &ctx.polymarket.down;
        let btc = &ctx.btc;

        // Need both token origins established and BTC origin locked.
        if up.origin_price.is_zero()
            || down.origin_price.is_zero()
            || btc.origin_price.is_zero()
        {
            return None;
        }

        let up_price = up.current_price.to_f64()?;
        let down_price = down.current_price.to_f64()?;

        if up_price <= 0.0 || down_price <= 0.0 {
            return None;
        }

        // ── Signal A: BTC macro range position ───────────────────────────
        //
        // range_position: 0.0 = at 5m low, 1.0 = at 5m high.
        // Near high → market expects BTC to fall → DOWN token hyped.
        // Near low  → market expects BTC to rise → UP token hyped.
        //
        // Threshold: 0.65 / 0.35 gives a clear majority without being too
        // tight (0.80 would be too rare).
        let btc_signal_hyped: Option<PredictionSide> =
            if btc.range_position >= 0.65 {
                Some(PredictionSide::Down) // DOWN hyped at BTC high
            } else if btc.range_position <= 0.35 {
                Some(PredictionSide::Up)   // UP hyped at BTC low
            } else {
                None // ambiguous
            };

        // ── Signal B: Window conviction (which side has been inflating) ───
        let up_conviction = Self::side_conviction(
            up.positive_points,
            up.area_under_curve,
            up.distance_from_origin_pct,
            up.imbalance,
        );
        let down_conviction = Self::side_conviction(
            down.positive_points,
            down.area_under_curve,
            down.distance_from_origin_pct,
            down.imbalance,
        );

        let conviction_hyped = if up_conviction >= down_conviction {
            PredictionSide::Up
        } else {
            PredictionSide::Down
        };
        let conviction_gap = (up_conviction - down_conviction).abs();

        // ── Combine signals ───────────────────────────────────────────────
        //
        // If BTC signal is available and agrees with conviction → strong.
        // If only conviction is available → moderate.
        // If BTC signal disagrees → use BTC signal (more fundamental) with
        //   a confidence penalty.
        let (hyped_side, signal_agreement_bonus) =
            match btc_signal_hyped {
                Some(btc_hyped) if btc_hyped == conviction_hyped => {
                    (btc_hyped, 20.0f64) // both agree — strong signal
                }
                Some(btc_hyped) => {
                    // BTC signal overrides; apply penalty for disagreement.
                    (btc_hyped, -10.0f64)
                }
                None => {
                    // No BTC extreme — rely on conviction only, lower bonus.
                    (conviction_hyped, 5.0f64)
                }
            };

        let trending_side = match hyped_side {
            PredictionSide::Up => PredictionSide::Down,
            PredictionSide::Down => PredictionSide::Up,
        };

        // ── Trending-token features ───────────────────────────────────────
        let (trending_feat, hyped_feat) = match trending_side {
            PredictionSide::Up   => (up, down),
            PredictionSide::Down => (down, up),
        };
        let (trending_price, hyped_price) = match trending_side {
            PredictionSide::Up   => (up_price, down_price),
            PredictionSide::Down => (down_price, up_price),
        };

        // ── Decay type classification ─────────────────────────────────────
        //
        // We look at three properties of the trending token:
        //
        //  1. distance_from_origin_pct — how far it has moved (signed,
        //     negative means it has fallen from its window-open price).
        //
        //  2. negative_points — cumulative sell-tick magnitude.
        //
        //  3. The ratio of negative_points to the total observed move.
        //     A large drop with FEW sell ticks = sudden cliff (Sudden).
        //     A large drop with MANY sell ticks = lots of small steps (Gradual).
        //
        // Note: distance_from_origin_pct is signed; for a falling token it
        // is negative.  We use the absolute value.
        let abs_drop = trending_feat.distance_from_origin_pct.abs();

        // Normalise negative_points to a 0–1 scale using a soft cap.
        // 10.0 points ≈ a ~1% cumulative price erosion over many ticks;
        // values above 20 indicate very heavy sustained selling.
        let neg_pts = trending_feat.negative_points;

        let decay_type = if abs_drop < 0.05 {
            // Less than 5% drop from origin — token has barely moved.
            DecayType::Flat
        } else if abs_drop >= 0.30 && neg_pts < abs_drop * 30.0 {
            // Dropped ≥30% but with relatively few sell ticks → sudden dump.
            DecayType::Sudden
        } else if abs_drop >= 0.15 {
            // Meaningful drop with proportional sell pressure → gradual decay.
            DecayType::Gradual
        } else {
            // Small but measurable drop — treat as flat/gradual boundary.
            DecayType::Flat
        };

        // ── Confidence scoring ────────────────────────────────────────────
        //
        // Base: 30 (requires positive contributions to be actionable)
        //
        // + BTC at extreme position (≥0.80 or ≤0.20): +20
        // + BTC moderately extreme (≥0.65 or ≤0.35):  +10
        // + BTC volatility (30s + 60s, scaled):        up to +20
        // + Trending token distance from origin:       up to +15
        // + Token price in ideal buy band (0.05–0.12): +15
        // + Token price in acceptable band (0.12–0.20): +5
        // + Signal agreement bonus:                    ±20 / ±5
        // + Conviction gap strength:                   up to +10

        let mut confidence = 30.0f64;

        // BTC position extremity.
        let btc_extremity_bonus = if btc.range_position >= 0.80
            || btc.range_position <= 0.20
        {
            20.0
        } else if btc.range_position >= 0.65 || btc.range_position <= 0.35 {
            10.0
        } else {
            0.0
        };
        confidence += btc_extremity_bonus;

        // BTC volatility — high volatility is the trigger for snap-backs.
        let btc_vol = btc.volatility_30s.max(btc.volatility_60s);
        let vol_score = (btc_vol * 2000.0).min(20.0);
        confidence += vol_score;

        // Trending token has actually fallen (provides the buy opportunity).
        let drop_score = (abs_drop * 60.0).min(15.0);
        confidence += drop_score;

        // Absolute price band — the strategy notes specify 0.05–0.12 as ideal.
        let price_band_bonus = if (0.05..=0.12).contains(&trending_price) {
            15.0
        } else if (0.12..0.20).contains(&trending_price) {
            5.0
        } else {
            0.0
        };
        confidence += price_band_bonus;

        // Signal agreement.
        confidence += signal_agreement_bonus;

        // Conviction gap — how convincingly one side dominates.
        let gap_score = (conviction_gap * 0.5).min(10.0);
        confidence += gap_score;

        let confidence = confidence.clamp(0.0, 100.0);

        Some(HypeAnalysis {
            hyped_side,
            trending_side,
            decay_type,
            confidence,
            trending_price_f64: trending_price,
            hyped_price_f64: hyped_price,
        })
    }

    // ─────────────────────────────────────────────────────────────────────
    // conviction_analysis — used to identify which side has been inflating.
    // ─────────────────────────────────────────────────────────────────────
    pub fn conviction_analysis(
        ctx: &PredictionContext,
        elapsed_seconds: f64,
    ) -> Option<ConvictionAnalysis> {
        let up = &ctx.polymarket.up;
        let down = &ctx.polymarket.down;

        if up.origin_price.is_zero() || down.origin_price.is_zero() {
            return None;
        }
        if ctx.btc.origin_price.is_zero() {
            return None;
        }

        let up_conviction = Self::side_conviction(
            up.positive_points,
            up.area_under_curve,
            up.distance_from_origin_pct,
            up.imbalance,
        );
        let down_conviction = Self::side_conviction(
            down.positive_points,
            down.area_under_curve,
            down.distance_from_origin_pct,
            down.imbalance,
        );

        let (dominant_side, conviction_gap) =
            if up_conviction >= down_conviction {
                (PredictionSide::Up, up_conviction - down_conviction)
            } else {
                (PredictionSide::Down, down_conviction - up_conviction)
            };

        let btc_dist = ctx.btc.distance_from_origin_pct;
        let btc_alignment = match dominant_side {
            PredictionSide::Up if btc_dist > 0.0 => 1.0,
            PredictionSide::Down if btc_dist < 0.0 => 1.0,
            _ => -1.0,
        };

        let confidence = (conviction_gap * 0.55
            + btc_alignment * 15.0
            + up.imbalance.abs() * 15.0
            + down.imbalance.abs() * 15.0)
            .clamp(0.0, 100.0);

        let elapsed = elapsed_seconds.max(1.0);
        let up_conviction_rate = up_conviction / elapsed;
        let down_conviction_rate = down_conviction / elapsed;

        Some(ConvictionAnalysis {
            dominant_side,
            conviction_gap,
            btc_alignment,
            confidence,
            up_conviction_rate,
            down_conviction_rate,
        })
    }

    /// Shared conviction formula — identical for both token sides.
    #[inline]
    fn side_conviction(
        positive_points: f64,
        area_under_curve: f64,
        distance_from_origin_pct: f64,
        imbalance: f64,
    ) -> f64 {
        positive_points * 0.45
            + area_under_curve * 0.35
            + distance_from_origin_pct.abs() * 100.0 * 0.15
            + imbalance.abs() * 0.05
    }
}