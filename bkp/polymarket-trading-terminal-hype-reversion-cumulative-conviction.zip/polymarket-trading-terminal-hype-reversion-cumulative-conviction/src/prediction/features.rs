use rust_decimal::Decimal;

#[derive(Debug, Clone, Default)]
pub struct BtcFeatures {
    pub current_price: Decimal,

    /// VWAP frozen from the first 3 s of the window.
    /// Zero until the BTC origin is locked.
    pub origin_price: Decimal,

    /// (current − origin) / origin — signed fraction.
    pub distance_from_origin_pct: f64,

    /// Time-weighted area under the BTC distance-from-origin curve.
    pub area_under_curve: f64,

    /// Cumulative upward-tick points: pct_change * 1000, positive ticks only.
    pub cumulative_bull_points: f64,

    /// Cumulative downward-tick magnitude: abs(pct_change) * 1000, negative ticks only.
    /// Stored separately so neither direction loses information.
    pub cumulative_bear_points: f64,

    // Retained as secondary signals — still useful for volatility context.
    pub high_5m: Decimal,
    pub low_5m: Decimal,
    pub volatility_30s: f64,
    pub volatility_60s: f64,

    /// Where BTC's current price sits within its 5-minute high/low range.
    /// 0.0 = at the 5m low, 1.0 = at the 5m high.
    /// Used to determine macro BTC position (high → DOWN token hyped,
    /// low → UP token hyped) per the mean-reversion strategy notes.
    pub range_position: f64,
}

#[derive(Debug, Clone, Default)]
pub struct TokenFeatures {
    pub current_price: Decimal,

    /// Price at the first trade of this token in the current window.
    pub origin_price: Decimal,

    /// (current − origin) / origin — signed fraction.
    pub distance_from_origin_pct: f64,

    /// Cumulative positive-tick points.  Only grows; never subtracted.
    pub positive_points: f64,

    /// Cumulative negative-tick magnitude.  Tracked separately; never
    /// subtracted from positive_points.
    pub negative_points: f64,

    /// Time-weighted AUC: Σ(distance_from_origin_pct * dt_seconds).
    pub area_under_curve: f64,

    // Orderbook — retained as secondary signals.
    pub bid_depth: Decimal,
    pub ask_depth: Decimal,
    pub imbalance: f64,
    pub spread_pct: f64,
}

#[derive(Debug, Clone, Default)]
pub struct PolymarketFeatures {
    pub up: TokenFeatures,
    pub down: TokenFeatures,
}