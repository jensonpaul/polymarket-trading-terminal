use std::sync::Arc;
use std::time::Duration;

use arc_swap::ArcSwap;
use rust_decimal::prelude::{FromPrimitive, ToPrimitive};
use rust_decimal::Decimal;
use tokio::sync::RwLock;
use tokio::time;
use tonic::transport::Channel;
use tracing::{error, info, warn};

use crate::prediction::{
    BtcFeatures,
    BtcSample,
    RollingWindow,
    WindowState,
};

pub mod proto {
    tonic::include_proto!("orderbook");
}

use proto::orderbook_aggregator_client::OrderbookAggregatorClient;

#[derive(Debug, Clone, Default)]
pub struct BtcSnapshot {
    pub timestamp_ms: u64,
    pub price: Decimal,
}

pub type SharedBtcSnapshot = Arc<ArcSwap<BtcSnapshot>>;

pub struct BtcFeed {
    port: u16,
    window: Arc<RwLock<RollingWindow<BtcSample>>>,
    snapshot: SharedBtcSnapshot,
    /// Shared with PolymarketFeed and PredictionService.
    window_state: Arc<RwLock<WindowState>>,
}

impl BtcFeed {
    pub fn new(
        port: u16,
        snapshot: SharedBtcSnapshot,
        window_state: Arc<RwLock<WindowState>>,
    ) -> Self {
        Self {
            port,
            snapshot,
            window_state,
            window: Arc::new(RwLock::new(
                RollingWindow::new(Duration::from_secs(300)),
            )),
        }
    }

    pub fn snapshot(&self) -> SharedBtcSnapshot {
        self.snapshot.clone()
    }

    /// Reset the window state for a new 5-minute market.
    /// Must be called by `PredictionService` whenever `active_window` changes,
    /// before any predictions are evaluated.
    pub async fn notify_window_start(&self, window_started_ms: u64) {
        self.window_state.write().await.reset(window_started_ms);
    }

    /// Returns `true` once the 3-second BTC origin VWAP has been frozen.
    /// `PredictionService` must not evaluate signals until this is `true`.
    pub async fn btc_origin_locked(&self) -> bool {
        self.window_state.read().await.btc_origin_locked
    }

    pub async fn run(&self) {
        loop {
            match self.run_connection().await {
                Ok(_) => {}
                Err(e) => error!("btc feed error: {e}"),
            }

            time::sleep(Duration::from_secs(5)).await;
        }
    }

    async fn connect(
        &self,
    ) -> anyhow::Result<OrderbookAggregatorClient<Channel>> {
        let addr = format!("http://[::1]:{}", self.port);
        Ok(OrderbookAggregatorClient::connect(addr).await?)
    }

    async fn run_connection(&self) -> anyhow::Result<()> {
        let mut client = self.connect().await?;

        info!("btc grpc connected");

        let request = tonic::Request::new(proto::Empty {});

        let mut stream = client
            .book_summary(request)
            .await?
            .into_inner();

        while let Some(summary) = stream.message().await? {
            if summary.bids.is_empty() || summary.asks.is_empty() {
                continue;
            }

            let mut bid_sum = 0.0;
            let mut bid_size = 0.0;

            for bid in &summary.bids {
                bid_sum += bid.price * bid.amount;
                bid_size += bid.amount;
            }

            let mut ask_sum = 0.0;
            let mut ask_size = 0.0;

            for ask in &summary.asks {
                ask_sum += ask.price * ask.amount;
                ask_size += ask.amount;
            }

            if bid_size <= 0.0 || ask_size <= 0.0 {
                continue;
            }

            let bid_vwap = bid_sum / bid_size;
            let ask_vwap = ask_sum / ask_size;
            let price = (bid_vwap + ask_vwap) / 2.0;

            let timestamp_ms =
                chrono::Utc::now().timestamp_millis() as u64;

            let decimal_price = Decimal::from_f64(price).unwrap_or_default();

            let sample = BtcSample {
                timestamp_ms,
                price: decimal_price,
            };

            self.window.write().await.push(sample.clone());

            // Feed the window-scoped conviction state.
            self.window_state
                .write()
                .await
                .ingest_btc(decimal_price, timestamp_ms);

            self.snapshot.store(Arc::new(BtcSnapshot {
                timestamp_ms,
                price: decimal_price,
            }));
        }

        warn!("btc stream disconnected");

        Ok(())
    }

    pub async fn features(&self) -> BtcFeatures {
        let window = self.window.read().await;
        let ws = self.window_state.read().await;

        let latest = match window.latest() {
            Some(v) => v,
            None => return BtcFeatures::default(),
        };

        let current_price = latest.price;

        let mut high = current_price;
        let mut low = current_price;

        let now_ms = latest.timestamp_ms;

        let mut prices_30s = Vec::new();
        let mut prices_60s = Vec::new();

        for sample in window.iter() {
            if sample.price > high {
                high = sample.price;
            }
            if sample.price < low {
                low = sample.price;
            }

            let age_ms = now_ms.saturating_sub(sample.timestamp_ms);

            let price_f = sample.price.to_f64().unwrap_or(0.0);

            if age_ms <= 30_000 {
                prices_30s.push(price_f);
            }
            if age_ms <= 60_000 {
                prices_60s.push(price_f);
            }
        }

        let current_f = current_price.to_f64().unwrap_or(0.0);
        let high_f = high.to_f64().unwrap_or(current_f);
        let low_f = low.to_f64().unwrap_or(current_f);
        let range_position = if high_f > low_f {
            (current_f - low_f) / (high_f - low_f)
        } else {
            0.5
        };

        BtcFeatures {
            current_price,
            origin_price: ws.btc_origin_price,
            distance_from_origin_pct: ws.btc_distance_from_origin_pct,
            area_under_curve: ws.btc_area,
            cumulative_bull_points: ws.btc_bull_points,
            cumulative_bear_points: ws.btc_bear_points,
            high_5m: high,
            low_5m: low,
            volatility_30s: volatility(&prices_30s),
            volatility_60s: volatility(&prices_60s),
            range_position,
        }
    }
}

fn volatility(prices: &[f64]) -> f64 {
    if prices.len() < 2 {
        return 0.0;
    }

    let mean = prices.iter().sum::<f64>() / prices.len() as f64;

    let variance = prices
        .iter()
        .map(|v| {
            let d = *v - mean;
            d * d
        })
        .sum::<f64>()
        / prices.len() as f64;

    variance.sqrt() / mean.max(1.0)
}